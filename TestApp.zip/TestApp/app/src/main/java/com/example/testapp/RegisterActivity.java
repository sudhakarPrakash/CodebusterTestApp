package com.example.testapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialAutoCompleteTextView;

import java.util.Objects;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    TextInputEditText mName_et, mMobile_et, mEmail_et;
    MaterialAutoCompleteTextView mGender_tv, mCity_tv;
    MaterialButton mRegister_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.app_name);

        mName_et = findViewById(R.id.et_name);
        mMobile_et = findViewById(R.id.et_mobileNo);
        mEmail_et = findViewById(R.id.et_emailId);

        mCity_tv = findViewById(R.id.tv_city);
        mGender_tv = findViewById(R.id.tv_gender);

        mRegister_btn = findViewById(R.id.btn_register);

        String[] genderArray = {"Male", "Female", "Transgender"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, genderArray);
        mGender_tv.setThreshold(1);
        mGender_tv.setAdapter(adapter);

        mRegister_btn.setOnClickListener(this);

//        if()

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_register:
                User newUser = createNewUser();
                if (checkFields(newUser)) {
                    //send User obj into database
                    //Save User data
                    //open user profile Activity
                    openUserProfileActivity();
                }
                break;
            default:
                break;
        }
    }

    private boolean checkFields(User newUser) {
        if (newUser.getName().isEmpty() || newUser.getCity().isEmpty() || newUser.getMobileNo().isEmpty() || newUser.getEmail().isEmpty() || newUser.getGender().isEmpty()) {
            Toast.makeText(this, "fill any empty fields", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    private User createNewUser() {
        User newUser = new User();
        newUser.setName(mName_et.getText().toString())
                .setCity(mCity_tv.getText().toString())
                .setMobileNo(mMobile_et.getText().toString())
                .setEmail(mEmail_et.getText().toString())
                .setGender(mGender_tv.getText().toString());

        return newUser;
    }

    private void openUserProfileActivity() {
//        Intent intent = new Intent(this,UserProfileActivity.class);
//        startActivity(intent);
    }

}
